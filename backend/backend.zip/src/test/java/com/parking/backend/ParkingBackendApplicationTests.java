package com.parking.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParkingBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
